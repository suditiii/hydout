
-- --------------------------------------------------------

--
-- Table structure for table `swishlist`
--

CREATE TABLE `swishlist` (
  `swid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `img1` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `swishlist`
--

INSERT INTO `swishlist` (`swid`, `uid`, `sid`, `name`, `description`, `img1`) VALUES
(2, 1, 8, 'F3 Cafe', 'F3 Cafe is the ultimate hangout spot, offering delicious food, indulgent drinks, and a lively atmosphere perfect for fun and relaxation.', 'https://b.zmtcdn.com/data/pictures/6/19157056/b9eef84021648623a3d3a7f49845c100.jpg?fit=around|960:500&crop=960:500;*,*');
