
-- --------------------------------------------------------

--
-- Table structure for table `ebooking`
--

CREATE TABLE `ebooking` (
  `ebid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `people` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL,
  `status` enum('confirmed','pending','cancelled','') NOT NULL,
  `final_cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ebooking`
--

INSERT INTO `ebooking` (`ebid`, `eid`, `uid`, `title`, `email`, `people`, `date`, `time`, `status`, `final_cost`) VALUES
(22, 4, 1, 'HOUDINI\'S MAGIC SHOW\r\n', 'suditisuditisuditisuditi@gmail.com', 2, '2025-02-04', '7:00PM', 'confirmed', 1155),
(23, 1, 11, 'Ed Sheeran +-=÷x 2025 India Tour in HYDERABAD\r\n', 'chitu@gmail.com', 6, '2025-02-12', '4:00PM', 'confirmed', 34650),
(24, 1, 6, 'Ed Sheeran +-=÷x 2025 India Tour in HYDERABAD\r\n', 'aaryarajsazena@gmail.com', 2, '2025-02-12', '4:00PM', 'confirmed', 11550),
(25, 1, 1, 'Ed Sheeran +-=÷x 2025 India Tour in HYDERABAD\r\n', 'suditisuditisuditisuditi@gmail.com', 2, '2025-02-12', '4:00PM', 'confirmed', 11550),
(26, 3, 1, 'Coldplay: Music of the Spheres World Tour', 'suditisuditisuditisuditi@gmail.com', 2, '2025-02-03', '6:00PM', 'confirmed', 4620),
(27, 2, 1, 'Samay Raina Unfiltered', 'suditisuditisuditisuditi@gmail.com', 3, '2025-03-27', '12:00PM', 'confirmed', 346),
(28, 8, 1, 'IPL:SRH vs RCB', 'suditisuditisuditisuditi@gmail.com', 2, '2025-04-19', '4:30PM', 'confirmed', 3518),
(29, 10, 1, '\"What is this?\" by Kanan Gill\r\n', 'suditisuditisuditisuditi@gmail.com', 1, '2025-03-24', '10:00AM', 'confirmed', 1155),
(30, 7, 1, 'दुस्स खत', 'suditisuditisuditisuditi@gmail.com', 2, '2025-02-13', '7:00PM', 'confirmed', 693),
(31, 7, 1, 'दुस्स खत', 'suditisuditisuditisuditi@gmail.com', 2, '2025-02-13', '7:00PM', 'confirmed', 693),
(32, 1, 5, 'Ed Sheeran +-=÷x 2025 India Tour in HYDERABAD\r\n', 'jules.moraes46@gmail.com', 4, '2025-02-12', '4:00PM', 'confirmed', 23100),
(33, 1, 5, 'Ed Sheeran +-=÷x 2025 India Tour in HYDERABAD\r\n', 'jules.moraes46@gmail.com', 4, '2025-02-12', '4:00PM', 'confirmed', 23100),
(34, 5, 5, 'Tech Workshop 2025', 'jules.moraes46@gmail.com', 7, '2025-04-22', '10:00AM', 'confirmed', 3840),
(35, 10, 6, '\"What is this?\" by Kanan Gill\r\n', 'aaryarajsazena@gmail.com', 2, '2025-03-24', '10:00AM', 'confirmed', 2310),
(36, 11, 1, 'Stand Up Comedy Open Mic\r\n', 'suditisuditisuditisuditi@gmail.com', 30, '2025-03-20', '5:00PM', 'confirmed', 0),
(37, 12, 1, 'THE GIRL OF MY DREAMS TOUR: FLETCHER', 'suditisuditisuditisuditi@gmail.com', 2, '2025-03-09', '6:00PM', 'confirmed', 6928);
