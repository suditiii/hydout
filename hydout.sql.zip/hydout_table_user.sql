
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `fullname` text NOT NULL,
  `email` text NOT NULL,
  `password` varchar(225) NOT NULL,
  `profile_picture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `fullname`, `email`, `password`, `profile_picture`) VALUES
(1, 'Suditi Ramchandani', 'suditisuditisuditisuditi@gmail.com', '$2y$10$aMWA035tu0F8SQvrxOTmYu186qXNyBQ1fzrrzxZgsCXABd4RKev/6', 'uploads/me.jpg'),
(2, 'Morris Mary Suzanne', 'morrissuzanne1904@gmail.com', '$2y$10$OR5LR7YwM5JA/sOv86xxZ.rgWrYhym0Vwwdr8P/0mLzpJHWOzaj9q', ''),
(3, 'vaishnavi ram', 'vaishnaviram@gmail.com', '$2y$10$Ich5n2ezaLmM/29x7Lvtl.6esBLIPSISlEjfVJuEB7GuplO/HxdZu', ''),
(4, 'Meetali Ramchandani', 'meetaligr@gmail.com', '$2y$10$2dAWgCZ4coCVU.STykaobOLHgAwT5MQ7EC0l14Cp9232GS.uzsFju', ''),
(5, 'Julisha Yes Moraes', 'jules.moraes46@gmail.com', '$2y$10$6IT8e/WFXLy1lMm7CJi1pe.h1Hc0IqGlIY/Kr1e/Y2ibL5uZ0NTHm', 'uploads/julu.jpg'),
(6, 'Aaryaraj Saxena', 'aaryarajsazena@gmail.com', '$2y$10$a0tiIgmbC0quwW1NJUWYyO7SCNZqthdwDsmiY2OvGNpO6Qa1zU2my', 'uploads/IMG-20241222-WA0048.jpg'),
(7, 'Joycee Moraes', 'joycee.moraes44@gmail.com', '$2y$10$.EmfDspf4DgDvosa5N9Zpe8RWiSV0OwztQquVpHn/cwnQypnQEaZK', ''),
(8, 'puja  iyer', 'bratzpuja@gmail.com', '$2y$10$nT4VDdBXbR0uFoW4n7vqeOINeN1gx.nTvJR1TjXnkkczKJfhgBp5S', ''),
(9, 'sania', '123@gmail.com', '$2y$10$MWvNaP2PkVAgxjoFtAK9FOEtt5f6g5YfN2z305FZIZuMg8k.7wC/i', ''),
(10, 'charvitha', 'saicharvithakare@gmail.com', '$2y$10$JbzP0C.Hu4Yb46sbvu4OD.x4cBosF8qppMAd1ZICiVkRoZrhHazg6', ''),
(11, 'Chitrakshi Ramchandani', 'chitu@gmail.com', '$2y$10$GnUQve4Gezvp1cnPqCpdE.sS0hq9KD26ffPm9J7Dk0RMJuycZHJte', 'uploads/IMG_0353.JPG'),
(12, 'Vaishnavi', 'vai@gmail.com', '$2y$10$iHzOSyTDiGSQUR7djbFQe.ClGCuXmYQYZuE545qCZN0w.jNPuJR.G', 'uploads/IMG20241129105640.jpg'),
(13, 'Shannon', 'shannon@gmail.com', '$2y$10$h2/2ylynj1ewIA7/X5gThu1SwovJjZs/Wq1XvSOAKt3YfgYfDyExy', '');
