
-- --------------------------------------------------------

--
-- Table structure for table `sreservations`
--

CREATE TABLE `sreservations` (
  `uid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sreservations`
--

INSERT INTO `sreservations` (`uid`, `sid`, `rid`, `date`, `time`) VALUES
(1, 5, 20, '2025-02-06', '12:30 PM'),
(1, 8, 21, '2025-02-18', '12:30 PM'),
(1, 5, 22, '2025-02-04', '12:30 PM');
