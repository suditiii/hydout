
-- --------------------------------------------------------

--
-- Table structure for table `suggestions`
--

CREATE TABLE `suggestions` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fullname` text NOT NULL,
  `email` text NOT NULL,
  `suggestion` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suggestions`
--

INSERT INTO `suggestions` (`id`, `uid`, `fullname`, `email`, `suggestion`, `created_at`) VALUES
(1, 1, 'Suditi', 'suditisuditisuditisuditi@gmail.com', 'this is a message', '2025-02-03 09:55:08'),
(2, 1, 'Suditi', 'suditisuditisuditisuditi@gmail.com', 'hiiiii', '2025-02-03 11:27:21'),
(3, 5, 'Julisha Moraes', 'jules.moraes46@gmail.com', 'what\'s up with the insane convenience fees?', '2025-02-04 06:50:01'),
(4, 5, 'Julisha Moraes', 'jules.moraes46@gmail.com', 'hiii', '2025-02-04 06:52:30'),
(5, 5, 'Julisha Moraes', 'jules.moraes46@gmail.com', 'hihi', '2025-02-04 06:52:47'),
(6, 5, 'Julisha Moraes', 'jules.moraes46@gmail.com', 'hi', '2025-02-04 06:53:33'),
(7, 5, 'Julisha Moraes', 'jules.moraes46@gmail.com', 'hi', '2025-02-04 06:53:55');
