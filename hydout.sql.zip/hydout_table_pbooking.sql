
-- --------------------------------------------------------

--
-- Table structure for table `pbooking`
--

CREATE TABLE `pbooking` (
  `bid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `people` int(11) NOT NULL,
  `bdate` date NOT NULL,
  `time_slot` varchar(50) NOT NULL,
  `status` enum('confirmed','pending','cancelled','') NOT NULL,
  `total_cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pbooking`
--

INSERT INTO `pbooking` (`bid`, `pid`, `uid`, `title`, `people`, `bdate`, `time_slot`, `status`, `total_cost`) VALUES
(85, 3, 1, 'Paint and Sip', 3, '2025-02-02', '10', 'confirmed', 10395),
(86, 1, 6, 'Thrill Seeker\'s Package', 1, '2025-02-02', '2', 'confirmed', 5775),
(87, 16, 1, 'Tie Dye', 7, '2025-02-04', '10', 'confirmed', 3234),
(88, 4, 1, 'Jewel of Nizam ', 11, '2025-02-03', '10', 'confirmed', 12705),
(89, 3, 12, 'Paint and Sip', 2, '2025-03-31', '10', 'confirmed', 6930),
(90, 15, 1, 'Nail Art', 2, '2025-02-12', '10', 'confirmed', 1848);
