
-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `email` text NOT NULL,
  `amount` double NOT NULL,
  `status` tinyint(4) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`tid`, `uid`, `email`, `amount`, `status`, `timestamp`) VALUES
(72, 5, 'jules.moraes46@gmail.com', 750, 1, '2025-01-29 10:58:24'),
(73, 5, 'jules.moraes46@gmail.com', 1200, 1, '2025-01-29 11:01:44'),
(74, 5, 'jules.moraes46@gmail.com', 600, 1, '2025-01-29 11:13:54'),
(75, 5, 'jules.moraes46@gmail.com', 600, 1, '2025-01-29 11:18:51'),
(76, 6, 'aaryarajsazena@gmail.com', 2000, 1, '2025-01-29 11:57:54'),
(77, 1, 'suditisuditisuditisuditi@gmail.com', 10000, 1, '2025-01-30 06:23:51'),
(78, 5, 'jules.moraes46@gmail.com', 2150, 1, '2025-01-31 08:56:06'),
(79, 5, 'jules.moraes46@gmail.com', 1000, 1, '2025-01-31 09:01:01'),
(80, 5, 'jules.moraes46@gmail.com', 1000, 1, '2025-01-31 09:04:07'),
(81, 5, 'jules.moraes46@gmail.com', 1000, 1, '2025-01-31 09:04:26'),
(82, 5, 'jules.moraes46@gmail.com', 1000, 1, '2025-01-31 09:09:02'),
(83, 5, 'jules.moraes46@gmail.com', 1000, 1, '2025-01-31 09:10:37'),
(84, 5, 'jules.moraes46@gmail.com', 20000, 1, '2025-01-31 09:44:15'),
(85, 5, 'jules.moraes46@gmail.com', 9138, 1, '2025-01-31 11:14:41'),
(86, 5, 'jules.moraes46@gmail.com', 0, 1, '2025-01-31 11:15:34'),
(87, 5, 'jules.moraes46@gmail.com', 3000, 1, '2025-01-31 15:30:38'),
(88, 6, 'aaryarajsazena@gmail.com', 3000, 1, '2025-01-31 21:24:56'),
(89, 1, 'suditisuditisuditisuditi@gmail.com', 7000, 1, '2025-02-01 06:45:04'),
(90, 1, 'suditisuditisuditisuditi@gmail.com', 7000, 1, '2025-02-01 06:45:07'),
(91, 1, 'suditisuditisuditisuditi@gmail.com', 7000, 1, '2025-02-01 06:45:09'),
(92, 1, 'suditisuditisuditisuditi@gmail.com', 2400, 1, '2025-02-01 20:42:24'),
(93, 1, 'suditisuditisuditisuditi@gmail.com', 2400, 1, '2025-02-01 20:42:27'),
(94, 1, 'suditisuditisuditisuditi@gmail.com', 1155, 1, '2025-02-02 14:45:57'),
(95, 1, 'suditisuditisuditisuditi@gmail.com', 10395, 1, '2025-02-02 14:54:30'),
(96, 11, 'chitu@gmail.com', 34650, 1, '2025-02-02 15:28:39'),
(97, 6, 'aaryarajsazena@gmail.com', 5775, 1, '2025-02-02 16:25:56'),
(98, 6, 'aaryarajsazena@gmail.com', 11550, 1, '2025-02-02 18:00:23'),
(99, 1, 'suditisuditisuditisuditi@gmail.com', 3234, 1, '2025-02-03 07:22:40'),
(100, 1, 'suditisuditisuditisuditi@gmail.com', 11550, 1, '2025-02-03 17:22:01'),
(101, 1, 'suditisuditisuditisuditi@gmail.com', 12705, 1, '2025-02-03 18:20:30'),
(102, 1, 'suditisuditisuditisuditi@gmail.com', 4620, 1, '2025-02-03 18:27:55'),
(103, 1, 'suditisuditisuditisuditi@gmail.com', 346.5, 1, '2025-02-04 05:18:58'),
(104, 1, 'suditisuditisuditisuditi@gmail.com', 3518.13, 1, '2025-02-04 05:22:07'),
(105, 1, 'suditisuditisuditisuditi@gmail.com', 1155, 1, '2025-02-04 06:16:27'),
(106, 1, 'suditisuditisuditisuditi@gmail.com', 693, 1, '2025-02-04 06:24:41'),
(107, 1, 'suditisuditisuditisuditi@gmail.com', 693, 1, '2025-02-04 06:25:06'),
(108, 12, 'vai@gmail.com', 6930, 1, '2025-02-04 06:34:52'),
(109, 5, 'jules.moraes46@gmail.com', 23100, 1, '2025-02-04 06:40:37'),
(110, 5, 'jules.moraes46@gmail.com', 23100, 1, '2025-02-04 06:40:42'),
(111, 5, 'jules.moraes46@gmail.com', 3840.375, 1, '2025-02-04 06:41:51'),
(112, 6, 'aaryarajsazena@gmail.com', 2310, 1, '2025-02-04 10:06:24'),
(113, 1, 'suditisuditisuditisuditi@gmail.com', 0, 1, '2025-02-04 11:21:00'),
(114, 1, 'suditisuditisuditisuditi@gmail.com', 6927.6900000000005, 1, '2025-02-08 14:00:55'),
(115, 1, 'suditisuditisuditisuditi@gmail.com', 1848, 1, '2025-02-08 14:08:55');
