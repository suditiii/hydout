
-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `image_url` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wid`, `uid`, `pid`, `title`, `description`, `image_url`) VALUES
(1, 1, 3, 'Paint and Sip', 'Pour the Wine, Pick Up the Brush, Create the Magic!', 'https://i.pinimg.com/736x/f3/42/04/f3420420b8eccc856b289950788c50a2.jpg'),
(2, 1, 4, 'Jewel of Nizam ', 'Nawabi Andaaz, Nizamon Ka Ehsaas!', 'https://i.pinimg.com/736x/45/80/f9/4580f91d203c66770f3be8ffd87243db.jpg'),
(3, 1, 6, 'Hot Stones', 'Relax, Rejuvenate, and Heal with the Power of Hot Stones', 'https://i.pinimg.com/736x/36/89/e4/3689e4fd5cda428996579a9ad164eb8e.jpg'),
(4, 1, 7, 'Bob Ross who?', 'fancy seeing you here, a happy accident perhaps?', 'https://i.pinimg.com/736x/d6/e8/c4/d6e8c492ef64d9dc54db474fe9a7f448.jpg');
